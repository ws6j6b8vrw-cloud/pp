#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""Единый Telegram-бот на основе настроек bot2.py.

Сохранена Telegram-логика второго бота; метод анализа связок мастей заменён
общим взвешенным анализом позиций, сочетаний игрок/банкир и прошлых игр.
Прогноз статистический и не гарантирует результат.
"""
from __future__ import annotations

import html
import json
import math
import os
import re
import time
from collections import Counter
from dataclasses import dataclass
from datetime import datetime
from typing import Any

import requests

# -------------------- Telegram-настройки: только bot2.py --------------------
SOURCE_WEB = "https://t.me/s/Stat_cerber"
INIT_FILE = "100k.txt"
POLL_INTERVAL = 15
TG_TIMEOUT = 15
TG_RETRIES = 3
TG_RETRY_DELAY = 3

# Один профиль: настройки второго исходного бота.
PROFILE = {
    "name": "VIP",
    "token": "5402326321:AAGQsrV70U9ljJWq78gcuX7evw9-jjELcqc",
    "channel": -1004376753726,
    "finished_only": True,
    "state_file": "plus2_web_state.json",
    "init_file": INIT_FILE,
}

SUITS = ('♠', '♣', '♥', '♦')
EMOJI = {'♠': '♠️', '♣': '♣️', '♥': '♥️', '♦': '♦️'}
EMOJI_TO_SUIT = {'♠️': '♠', '♣️': '♣', '♥️': '♥', '♦️': '♦', '♠': '♠', '♣': '♣', '♥': '♥', '♦': '♦'}
SEP = "━━━━━━━━━━━━━━━━━━"


def suits_in(text: str) -> list[str]:
    # Поддерживает символы мастей с variation selector и без него.
    return [c for c in text if c in SUITS]


def parse_message(msg: str) -> dict | None:
    tm = re.search(r'Дата:\s*(\d{4}-\d\d-\d\d[ T]\d\d:\d\d:\d\d(?:[+-]\d\d:\d\d|Z)?)', msg)
    text_match = re.search(r'Текст:\s*(.+?)(?=\n\s*\n|\n=|$)', msg, re.S)
    text = ' '.join((text_match.group(1) if text_match else msg).split())
    num = re.search(r'#n\s*(\d+)', text)
    if not num:
        return None
    brackets = re.findall(r'\(([^()]*)\)', text)
    if len(brackets) < 2:
        return None
    player, banker = suits_in(brackets[0]), suits_in(brackets[1])
    if not player or not banker:
        return None
    date = None
    if tm:
        try:
            date = datetime.fromisoformat(tm.group(1).replace('Z', '+00:00'))
        except ValueError:
            pass
    finished = ('✅' in text or '🔰' in text)
    is_tie = ('🔰' in text or re.search(r'(?<!\w)#X(?!\w)', text, re.I) is not None)
    is_2_3 = re.search(r'(?<!\w)#C2_3(?!\w)', text, re.I) is not None
    return {
        'number': int(num.group(1)), 'date': date, 'text': text,
        'player': player, 'banker': banker,
        'player_key': tuple(sorted(player)), 'banker_key': tuple(sorted(banker)),
        'finished': finished, 'is_tie': is_tie, 'is_2_3': is_2_3,
        'skip_prediction': is_tie or is_2_3,
    }


def parse_file_records(path: str, finished_only: bool = False) -> list[dict]:
    if not os.path.exists(path):
        print(f"[file] нет файла {path}")
        return []
    with open(path, 'r', encoding='utf-8-sig', errors='replace') as f:
        content = f.read()
    parsed = []
    for block in re.split(r'={50,}', content):
        if not block.strip():
            continue
        game = parse_message(block)
        if game and (not finished_only or game['finished']):
            parsed.append(game)
    # Экспорт обычно записан от новых к старым. Даты, если есть у всех,
    # надёжнее номера #n: номера могут сбрасываться и повторяться.
    if parsed and all(g.get('date') is not None for g in parsed):
        try:
            parsed.sort(key=lambda g: g['date'])
        except TypeError:
            parsed.reverse()
    else:
        parsed.reverse()
    print(f"[file:{'finished' if finished_only else 'all'}] разобрано игр: {len(parsed)}")
    if parsed:
        print(f"   Первая (старая): #{parsed[0]['number']}, Последняя (новая): #{parsed[-1]['number']}")
    return parsed


def _strip_html(s: str) -> str:
    s = re.sub(r'<[^>]+>', ' ', s)
    return html.unescape(s).strip()


def fetch_web_games(finished_only: bool = False) -> list[dict]:
    try:
        r = requests.get(SOURCE_WEB, headers={'User-Agent': 'Mozilla/5.0'}, timeout=15)
    except Exception as e:
        print(f"[web] ОШИБКА СЕТИ: {e}")
        return []
    if r.status_code != 200:
        print(f"[web] HTTP {r.status_code}")
        return []
    blocks = re.findall(
        r'<div class="tgme_widget_message[^\"]*"[^>]*>(.*?)(?=<div class="tgme_widget_message|$)',
        r.text, re.DOTALL,
    )
    out = []
    for idx, block in enumerate(blocks):
        text = _strip_html(block)
        if finished_only and '✅' not in text and '🔰' not in text:
            continue
        if not finished_only and '#n' not in text and '✅' not in text and '🔰' not in text:
            continue
        game = parse_message(text)
        if game:
            game['uid'] = f"w{idx}_{game['number']}"
            out.append(game)
    # Не сортируем по #n: порядок в HTML соответствует ленте канала.
    print(f"[web:{'finished' if finished_only else 'all'}] игр: {len(out)}")
    return out


# -------------------- Новый метод анализа всех связей мастей --------------------
def _game_positions(game: dict) -> dict[str, str]:
    out = {}
    for side, key in (('P', 'player'), ('B', 'banker')):
        cards = game.get(key, [])
        for i in range(3):
            if i < len(cards):
                out[f'{side}{i+1}'] = cards[i]
    return out


def _pattern(cards: list[str]) -> str:
    return ''.join(cards) if cards else '-'


def _context_features(games: list[dict], idx: int, max_lag: int = 4) -> dict[str, tuple[str, float]]:
    """Возвращает набор признаков контекста, не используя будущие игры."""
    features: dict[str, tuple[str, float]] = {}
    current = games[idx]
    pos = _game_positions(current)
    # Отдельные позиции и полные последовательности игрока/банкира.
    for key, value in pos.items():
        features[f'pos:{key}'] = (value, 1.35)
    features['pattern:P'] = (_pattern(current.get('player', [])), 2.0)
    features['pattern:B'] = (_pattern(current.get('banker', [])), 2.0)
    features['pattern:PB'] = (_pattern(current.get('player', []) + current.get('banker', [])), 2.7)
    # Все позиционные связи игрок-банкир в текущей игре.
    for p in ('P1', 'P2', 'P3'):
        for b in ('B1', 'B2', 'B3'):
            if p in pos and b in pos:
                features[f'cross:{p}-{b}'] = (pos[p] + pos[b], 1.8)
    # Контекст предыдущих игр: позиции и полные связки по каждому лагу.
    for lag in range(1, max_lag + 1):
        j = idx - lag
        if j < 0:
            break
        prev = games[j]
        ppos = _game_positions(prev)
        for key, value in ppos.items():
            features[f'lag{lag}:{key}'] = (value, 0.85)
        features[f'lag{lag}:P'] = (_pattern(prev.get('player', [])), 1.15)
        features[f'lag{lag}:B'] = (_pattern(prev.get('banker', [])), 1.15)
        features[f'lag{lag}:PB'] = (_pattern(prev.get('player', []) + prev.get('banker', [])), 1.35)
    # Последовательности между играми: позиция → та же позиция и P/B → P/B.
    for lag in range(1, min(max_lag, idx) + 1):
        prev_pos = _game_positions(games[idx-lag])
        for key in set(pos) & set(prev_pos):
            features[f'seq{lag}:{key}'] = (prev_pos[key] + pos[key], 1.55 if lag == 1 else 1.15)
        pp = games[idx-lag].get('player', [])
        bb = games[idx-lag].get('banker', [])
        features[f'seq{lag}:PtoP'] = (_pattern(pp) + '>' + _pattern(current.get('player', [])), 1.5)
        features[f'seq{lag}:BtoB'] = (_pattern(bb) + '>' + _pattern(current.get('banker', [])), 1.5)
        features[f'seq{lag}:PtoB'] = (_pattern(pp) + '>' + _pattern(current.get('banker', [])), 1.35)
        features[f'seq{lag}:BtoP'] = (_pattern(bb) + '>' + _pattern(current.get('player', [])), 1.35)
    # Последовательности 1–2–3–4 по ключевым позициям, где все значения доступны.
    for key in ('P1', 'P2', 'P3', 'B1', 'B2', 'B3'):
        vals = []
        for j in range(max(0, idx-3), idx+1):
            v = _game_positions(games[j]).get(key)
            if v is None:
                vals = []
                break
            vals.append(v)
        if len(vals) >= 2:
            features[f'run:{key}:{len(vals)}'] = (''.join(vals), 1.65)
    return features


class AIPredictor:
    """Объединённый predictor. Интерфейс predict() сохранён для Telegram-логики."""
    def __init__(self, history: list[dict], offset: int = 2, min_exact: int = 3, neighbors: int = 120):
        self.history = history
        self.offset = offset
        self.min_exact = min_exact
        self.neighbors = neighbors
        self._feature_cache: dict[int, dict[str, tuple[str, float]]] = {}
        for i in range(len(history)):
            self._feature_cache[i] = _context_features(history, i)

    @staticmethod
    def _target_presence(game: dict) -> set[str]:
        return set(game.get('player', []))

    @staticmethod
    def _similarity(a: dict, b: dict) -> float:
        # Взвешенное сходство признаков. Точное совпадение сложных связок имеет
        # больший вес, но частичные совпадения позиций тоже учитываются.
        common = 0.0
        total = 0.0
        for key, (value, weight) in a.items():
            total += weight
            other = b.get(key)
            if other and other[0] == value:
                common += min(weight, other[1])
        return common / total if total else 0.0

    def _live_features(self, current: dict) -> dict[str, tuple[str, float]]:
        # Если последняя запись истории и current — одна игра, использовать её
        # как текущий контекст; иначе добавляем live-игру в конец хронологии.
        if self.history and self.history[-1].get('number') == current.get('number') and \
           self.history[-1].get('player') == current.get('player') and \
           self.history[-1].get('banker') == current.get('banker'):
            return self._feature_cache[len(self.history)-1]
        return _context_features(self.history + [current], len(self.history))

    def _distribution(self, current: dict) -> tuple[dict[str, float], int, str]:
        n = len(self.history)
        if n <= self.offset:
            return {}, 0, 'недостаточно истории'
        query = self._live_features(current)
        candidates = []
        # Исторический контекст i сопоставляется с результатом i + offset.
        # Последние offset контекстов не имеют целевого результата и исключены.
        for i in range(0, n - self.offset):
            feats = self._feature_cache[i]
            sim = self._similarity(query, feats)
            if sim > 0:
                # Небольшой recency bonus, чтобы свежая история была чуть весомее.
                recency = 0.75 + 0.25 * ((i + 1) / n)
                candidates.append((sim * sim * recency, i))
        candidates.sort(reverse=True)
        selected = candidates[:self.neighbors]

        # Базовая частота: доля игр +2, в которых встречалась каждая масть игрока.
        targets = [self.history[i + self.offset] for i in range(n - self.offset)]
        baseline = {s: (sum(s in g.get('player', []) for g in targets) + 1.0) / (len(targets) + 2.0) for s in SUITS}
        if not selected:
            return baseline, len(targets), 'базовая частота мастей игрока'

        weighted_presence = Counter()
        total_weight = 0.0
        for weight, i in selected:
            target = self.history[i + self.offset]
            total_weight += weight
            for suit in self._target_presence(target):
                weighted_presence[suit] += weight
        # Сглаживаем локальные связи базовой статистикой, чтобы несколько
        # редких совпадений не давали ложные 100%.
        strength = total_weight / (total_weight + 2.5)
        probs = {}
        for suit in SUITS:
            local = weighted_presence[suit] / total_weight if total_weight else baseline[suit]
            probs[suit] = strength * local + (1.0 - strength) * baseline[suit]
        method = f'все связи P/B + позиции + последовательности (сравнено {len(selected)} примеров)'
        return probs, len(selected), method

    def predict(self, current: dict):
        try:
            dist, examples, method = self._distribution(current)
            if not dist:
                return None, None, None
            best = max(SUITS, key=lambda s: dist.get(s, 0.0))
            prob = 100.0 * dist[best]
            return EMOJI[best], method, prob
        except Exception as e:
            print(f'❌ Ошибка прогноза: {e}')
            return None, None, None


def check_prediction_result(game: dict, target_suit_emoji: str, finished_only: bool = True) -> bool:
    if finished_only and not game.get('finished', False):
        return False
    target_suit = EMOJI_TO_SUIT.get(target_suit_emoji, target_suit_emoji)
    return target_suit in game.get('player', [])


# -------------------- Telegram API: тот же способ отправки/редактирования --------------------
def send_telegram_message(profile: dict, text: str) -> int | None:
    url = f"https://api.telegram.org/bot{profile['token']}/sendMessage"
    for attempt in range(1, TG_RETRIES + 1):
        try:
            r = requests.post(url, data={'chat_id': profile['channel'], 'text': text, 'parse_mode': 'HTML'}, timeout=TG_TIMEOUT)
            if r.status_code == 200:
                return r.json()['result']['message_id']
            print(f"[{profile['name']} send] HTTP {r.status_code}: {r.text[:200]}")
        except Exception as e:
            print(f"[{profile['name']} send] попытка {attempt}/{TG_RETRIES}: {e}")
        if attempt < TG_RETRIES:
            time.sleep(TG_RETRY_DELAY)
    return None


def edit_telegram_message(profile: dict, message_id: int, text: str) -> bool:
    url = f"https://api.telegram.org/bot{profile['token']}/editMessageText"
    for attempt in range(1, TG_RETRIES + 1):
        try:
            r = requests.post(url, data={'chat_id': profile['channel'], 'message_id': message_id, 'text': text, 'parse_mode': 'HTML'}, timeout=TG_TIMEOUT)
            if r.status_code == 200 or 'message is not modified' in r.text:
                return True
            print(f"[{profile['name']} edit] HTTP {r.status_code}: {r.text[:200]}")
        except Exception as e:
            print(f"[{profile['name']} edit] попытка {attempt}/{TG_RETRIES}: {e}")
        if attempt < TG_RETRIES:
            time.sleep(TG_RETRY_DELAY)
    return False


def load_state(profile: dict) -> dict:
    path = profile['state_file']
    if os.path.exists(path):
        try:
            with open(path, 'r', encoding='utf-8') as f:
                state = json.load(f)
            state.setdefault('pending', {})
            state.setdefault('last_processed_num', 0)
            state.setdefault('skip_remaining', 0)
            return state
        except Exception as e:
            print(f"[{profile['name']} state] Не удалось прочитать состояние: {e}")
    return {'last_processed_num': 0, 'pending': {}, 'skip_remaining': 0}


def save_state(profile: dict, state: dict) -> None:
    with open(profile['state_file'], 'w', encoding='utf-8') as f:
        json.dump(state, f, ensure_ascii=False, indent=2)


def format_new_prediction(target_num, current_game, suit, method=None, prob=None):
    return (f"🎯 <b>Игра #{target_num}</b>\n"
            f"🃏 <b>Масть:</b> {suit}\n"
            f"🔁 <b>Догон:</b> 0/3")


def format_hit(target_num, suit, idx, num, base_info=None):
    return (f"🎯 <b>Игра #{target_num}</b>\n"
            f"🃏 <b>Масть:</b> {suit}\n"
            f"🔁 <b>Догон:</b> {idx}/3 · ✅ Зашло")


def format_miss(target_num, suit, num, remaining, base_info=None):
    dogon = 4 - len(remaining) if remaining else 3
    status = f"⏳ Проверена игра #{num}" if remaining else "❌ Догоны закончились"
    return (f"🎯 <b>Игра #{target_num}</b>\n"
            f"🃏 <b>Масть:</b> {suit}\n"
            f"🔁 <b>Догон:</b> {dogon}/3 · {status}")



def retry_pending_edits(profile: dict, pending: dict) -> None:
    for pred_key, pred in list(pending.items()):
        status = pred.get('final_status')
        if not status:
            continue
        suit = pred['target_suit']
        base_info = pred.get('base_text', '')
        num = pred.get('final_game', 0)
        if status == 'hit':
            text = format_hit(pred_key, suit, pred.get('final_idx', 0), num, base_info)
        else:
            text = format_miss(pred_key, suit, num, [], base_info)
        if edit_telegram_message(profile, pred['message_id'], text):
            del pending[pred_key]
            print(f"[{profile['name']} retry-edit] {pred_key} ({status}) завершено")


def _wrap_num(n: int) -> int:
    return (n - 1) % 1440 + 1


def run_profile(profile: dict) -> None:
    name = profile['name']
    print('=' * 58)
    print(f"[{name}] Запуск. Завершённые игры: {profile['finished_only']}")
    history = parse_file_records(profile['init_file'], profile['finished_only'])
    if len(history) < 100:
        print(f"[{name}] ❌ В истории меньше 100 игр — профиль остановлен.")
        return
    predictor = AIPredictor(history, offset=2)
    state = load_state(profile)
    pending = state['pending']
    last_processed_num = state['last_processed_num']
    skip_remaining = int(state.get('skip_remaining', 0))
    last_web_num = 0
    print(f"[{name}] Последняя обработанная игра: #{last_processed_num}; бот работает.")

    while True:
        try:
            web_games = fetch_web_games(profile['finished_only'])
            if not web_games:
                retry_pending_edits(profile, pending)
                state['pending'] = pending
                save_state(profile, state)
                time.sleep(POLL_INTERVAL)
                continue

            # Повтор неудачных edits оставлен только для bot2, как в исходнике.
            if profile['finished_only']:
                retry_pending_edits(profile, pending)

            # Проверка догона по правилам исходного bot2: только завершённая игра.
            for game in web_games:
                if profile['finished_only'] and not game.get('finished'):
                    continue
                num = game['number']
                # Tie and 2/3 hands are excluded from all dogon checks.
                if game.get('skip_prediction'):
                    continue
                for pred_key, pred in list(pending.items()):
                    if (profile['finished_only'] and pred.get('final_status')) or not pred.get('check_games') or num != pred['check_games'][0]:
                        continue
                    suit = pred['target_suit']
                    base_info = pred.get('base_text', '')
                    has = check_prediction_result(game, suit, finished_only=profile['finished_only'])
                    original = pred.get('original_check_games', [])
                    idx = original.index(num) if num in original else 0
                    if has:
                        ok = edit_telegram_message(profile, pred['message_id'], format_hit(pred_key, suit, idx, num, base_info))
                        if ok:
                            del pending[pred_key]
                            print(f"[{name} dog] {pred_key} зашёл в #{num}")
                        else:
                            pred['final_status'] = 'hit'; pred['final_game'] = num; pred['final_idx'] = idx
                    else:
                        pred['check_games'].pop(0)
                        if pred['check_games']:
                            edit_telegram_message(profile, pred['message_id'], format_miss(pred_key, suit, num, pred['check_games'], base_info))
                            print(f"[{name} dog] {pred_key} не зашёл в #{num}")
                        else:
                            ok = edit_telegram_message(profile, pred['message_id'], format_miss(pred_key, suit, num, [], base_info))
                            if ok:
                                del pending[pred_key]
                                print(f"[{name} dog] {pred_key} проиграл 4 игры")
                            else:
                                pred['final_status'] = 'lose'; pred['final_game'] = num
            state['pending'] = pending
            save_state(profile, state)

            # bot1 historically acts on latest poll; bot2 acts only on a new latest number.
            latest_game = web_games[-1]
            latest_num = latest_game['number']
            if latest_num != last_web_num:
                print(f"[{name}] Новая игра #{latest_num}")
                last_web_num = latest_num
            if profile['finished_only'] and latest_num == last_processed_num:
                time.sleep(POLL_INTERVAL)
                continue

            # X (🔰 / #X) or 2/3 (#C2_3): skip that hand and the next 3 games.
            if latest_game.get('skip_prediction'):
                skip_remaining = 3
                reason = 'ничья X' if latest_game.get('is_tie') else 'раздача 2/3'
                print(f"[{name}] #{latest_num}: {reason}; пропускаю следующие 3 игры.")
            elif skip_remaining > 0:
                skip_remaining -= 1
                print(f"[{name}] #{latest_num}: пропуск после X/2-3; осталось пропустить {skip_remaining}.")
            else:
                target_num = _wrap_num(latest_num + 2)
                pred_key = str(target_num)
                if pred_key not in pending and len(pending) < 5:
                    suit, method, prob = predictor.predict(latest_game)
                    if suit:
                        msg = format_new_prediction(target_num, latest_game, suit)
                        message_id = send_telegram_message(profile, msg)
                        if message_id:
                            check_games = [_wrap_num(target_num + i) for i in range(4)]
                            pending[pred_key] = {
                                'check_games': check_games,
                                'original_check_games': check_games.copy(),
                                'message_id': message_id,
                                'target_suit': suit,
                                'base_text': '',
                            }
                            print(f"[{name} new] Прогноз на #{target_num} ({suit}) от #{latest_num}")
                    else:
                        print(f"[{name}] Не удалось сделать прогноз для #{latest_num}")

            last_processed_num = latest_num
            state['last_processed_num'] = last_processed_num
            state['pending'] = pending
            state['skip_remaining'] = skip_remaining
            save_state(profile, state)
            time.sleep(POLL_INTERVAL)
        except KeyboardInterrupt:
            print(f"[{name}] остановлен")
            return
        except Exception as e:
            print(f"[{name} loop] Ошибка: {e}")
            time.sleep(30)


def main() -> None:
    # Запускается ровно один бот — второй исходный профиль.
    try:
        run_profile(PROFILE)
    except KeyboardInterrupt:
        print('Остановка по Ctrl+C...')


if __name__ == '__main__':
    main()
